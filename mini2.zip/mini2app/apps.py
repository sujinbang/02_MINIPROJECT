from django.apps import AppConfig


class Mini2AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mini2app'
